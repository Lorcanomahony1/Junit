package ie.atu.dip;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterEach;

public class BankingAppTest {
    private BankingApp bank;

    //SETS UP A NEW BANKING APP BEFORE THE TESTS
    @BeforeEach
    void setUp() {
        bank = new BankingApp();
    }
    
    //REMOVES EACH BANKING APP BEFORE EACH TESTS
    @AfterEach
    void resetAll() {
        bank.removeAccount("Lorcan");
        bank.findAccount("Lorcan");
    }

    //TESTS THE ADDACOUNT METHOD
    @Test
    @Timeout(value = 50, unit = TimeUnit.MILLISECONDS)
    void addAccountTest() {
        bank.addAccount("Lorcan", 1000);
        bank.findAccount("Lorcan");
        assertFalse(bank.deposit("John", 100));

    }
    
    //TESTS THAT THE VALUES IN ADDACOUNT MATCH THE VALUES VALUES INPUT INTO THE ADDACOUNT FUNCTION
    @ParameterizedTest
    @CsvSource({"Lorcan, 1000"})
    public void ParameterizedTest(String name, int balance) {
    	bank.addAccount("Lorcan", 1000);
        assertEquals(bank.findAccount("Lorcan"), bank.findAccount(name));
        assertEquals(bank.getBalance("Lorcan"), balance);
    }
    
    
    
    //DOING BOUNDARY TESTING ON THE DEPOSITS TO MAKE SURE IT CAN HANDLE A RANGE OF DEPOSIT VALUES
    @ParameterizedTest
    @CsvSource({
        "Lorcan, -1000",
        "John, 0",
        "Joe, 2000",
        "Bob, 999089898"
    })
    void parameterizedBoundaryTest(String name, int balance) {
        bank.addAccount(name, balance);
        assertEquals(balance, bank.getBalance(name));
    }

    
    
    
    //TESTS THAT THE TOTAL DEPOSITS WORKS
    @Test
    @Timeout(value = 50, unit = TimeUnit.MILLISECONDS)
    void totalDepositTest() {
        bank.addAccount("Lorcan", 1000);
        bank.addAccount("Joe", 2000);
        bank.removeAccount("Lorcan");
        assertEquals(bank.getTotalDeposits(), 2000);

    }

    
    //TESTS THE BALANCE WORKS
    @Test
    @Timeout(value = 50, unit = TimeUnit.MILLISECONDS)
    void getBalanceTest() {
        bank.addAccount("Lorcan", 200);
        assertEquals(200, bank.getBalance("Lorcan"));
    }
    
    //TESTS THAT DEPOSITS WORK
    @Test
    @Timeout(value = 50, unit = TimeUnit.MILLISECONDS)
    void depostitTest() {
        bank.addAccount("Lorcan", 500);
        assertTrue(bank.deposit("Lorcan", 200));
        assertEquals(700, bank.getBalance("Lorcan"));
    }

    
    //TESTS THAT WITHDRAWS WORK
    @Test
    @Timeout(value = 50, unit = TimeUnit.MILLISECONDS)
    void withdrawTest() {
        bank.addAccount("Lorcan", 500);
        assertTrue(bank.withdraw("Lorcan", 300));
        assertEquals(200, bank.getBalance("Lorcan"));
        assertEquals(200, bank.getTotalDeposits());
       //Testing if withdrawals work when there are no money in account
        assertFalse(bank.withdraw("Lorcan", 3000));
    }



    //TESTS THAT APPROVESLOANS WORKS
    @Test
    @Timeout(value = 50, unit = TimeUnit.MILLISECONDS)
    void approveLoanTest() {
        bank.addAccount("Lorcan", 1000);
        assertTrue(bank.approveLoan("Lorcan", 400));
        assertEquals(400, bank.getLoan("Lorcan"));
        assertEquals(600, bank.getTotalDeposits());
        //TEST THAT LOANS ONLY WORK ON ACCOUNTS
        assertFalse(bank.approveLoan("ChickenNuggets", 100));
        //LOAN GREATER THAN FUNDS
        assertFalse(bank.approveLoan("Lorcan", 2000));
        assertEquals(400, bank.getLoan("Lorcan"));

    }
    
    
    //TESTS THAT REPAYLOANS WORKS
    @Test
    @Timeout(value = 50, unit = TimeUnit.MILLISECONDS)
    void repayLoanTest() {
        bank.addAccount("Lorcan", 1000);
        bank.approveLoan("Lorcan", 400);
        assertTrue(bank.repayLoan("Lorcan", 200));
        assertEquals(200, bank.getLoan("Lorcan"));
        assertEquals(800, bank.getTotalDeposits());
        assertFalse(bank.repayLoan("Lorcan", -500));
        assertEquals(200, bank.getLoan("Lorcan"));
        assertNull(bank.getBalance("George"));
        assertNull(bank.getLoan("George"));
        assertFalse(bank.repayLoan("George", 100));
    }


}


