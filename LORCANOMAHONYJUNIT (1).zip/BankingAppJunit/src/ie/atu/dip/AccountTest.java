

package ie.atu.dip;
import static org.junit.jupiter.api.Assertions.*;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

	
	public class AccountTest {
		
	    private Account account;
	    private static BankingApp bank; 
	    
	    
	    //THIS SETS UP THE BANKINGAPP BEFORE THE ACCOUNT BECAUSE BANKING APP CLASS NEEDS TO BE CREATED FOR ACCOUNT TO WORK
	    // A NEW BANKING APP IS SET UP EACH TIME 
	    @BeforeAll 
	    static void setUpBank() {
	    	bank = new BankingApp();
	    }

	    // THIS CREATES A NEW ACCOUNT BEFORE EACH TEST IS RUN, SO TESTS ARE NOT AFFECTED BY THE PREVIOUS TESTS
	    @BeforeEach
	    void setUpAccount() {
	        account = new Account("Lorcan O'Mahony", 100000);
	    }
	    
	    //THIS ENSURES THAT EVERYTHING IS RESET SO EACH TEST IS NOT AFFECTED BY PREVIOUS TESTS
	    @AfterEach
	    @Timeout(value = 50, unit = TimeUnit.MILLISECONDS)
	    void ResetEverything() {
	    	bank.getTotalDeposits();
	    	bank.removeAccount("");
	    	bank.findAccount("");
	    }

	    
	    //THIS TESTS ACCOUNT CREATION
	    @Test
	    @Timeout(value = 50, unit = TimeUnit.MILLISECONDS)
	    void createAccountTest() {
	        assertEquals("Lorcan O'Mahony", account.getAccountHolder(), "Account creation failed");
	        assertEquals(100000, account.getBalance(), "The balance did not match the account you created");
	        assertEquals(0, account.getLoan(), "Loan error, loan should be zero");
	    }

	    //THIS TESTS DEPOSITS
	    @Test
	    @Timeout(value = 50, unit = TimeUnit.MILLISECONDS)
	    void depositTest() {
	        account.deposit(1500);
	        assertEquals(101500, account.getBalance(), "Deposit error");
	    }

	    //THIS TESTS WITHDRAWAL
	    @Test
	    @Timeout(value = 50, unit = TimeUnit.MILLISECONDS)
	    void withdrawTest() {
	        boolean result = account.withdraw(100);
	        assertTrue(result);
	        assertEquals(99900, account.getBalance(), "widthdrawal success");
	        boolean result2 = account.withdraw(99999999);
	        assertFalse(result2, "You are attempting to withdraw this amount");
	        assertNotEquals(99999999, account.getBalance(), "Insufficient funds");
	    
	    }

	

	    //THIS TESTS THE LOAN APPROVAL FUNCTION
	    @Test
	    @Timeout(value = 50, unit = TimeUnit.MILLISECONDS)
	    void approveLoanTest() {
	        account.approveLoan(3000);
	        assertEquals(3000, account.getLoan());
	    }

	    
	    //THIS TESTS THE REPAY LOAN FUNCTION
	    @Test
	    @Timeout(value = 50, unit = TimeUnit.MILLISECONDS)
	    void repayLoanTest() {
	        account.approveLoan(2000);
	        boolean result = account.repayLoan(1000);
	        assertTrue(result);
	        assertEquals(1000, account.getLoan());     
	        boolean result2 = account.repayLoan(5000);
	        assertFalse(result2);
	        assertEquals(1000, account.getLoan());
	    }

	    
	    //THIS RESETS EVERYTHING AFTER ALL OF THE TEST ARE RUN AND REMOVES THE BANK INSTANCE
	    @AfterAll
	    static void resetAll() {
	    	bank.getTotalDeposits();
	    	bank.removeAccount("");
	    	bank.findAccount("");
	    	bank = null;
	    }
	    
	}
	
	
	
	
	
	

